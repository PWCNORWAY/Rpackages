library(testthat)
library(rClr)
cTypename <- "Rclr.TestCases"
testClassName <- "Rclr.TestObject"
