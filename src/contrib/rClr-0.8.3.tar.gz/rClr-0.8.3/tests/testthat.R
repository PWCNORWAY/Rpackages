library(testthat)
library(rClr)

debug_test = FALSE
# debug_test = TRUE

test_check("rClr")
