﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rclr
{
    /// <summary>
    /// Support for the package vignette
    /// </summary>
    public class HelloWorld
    {
        public static string Hello() { return "Hello, World!"; }
    }
}
